# Group contributions

Group: EF101-P11 - Computer Hardware Inventory and Maintenance System

| Member | Main area | Meaningful contributions (specific tasks) | Commits / folder |
|---|---|---|---|
| Member 1 - name | Database | | `database/` |
| Member 2 - name | Backend | | `backend/` |
| Member 3 - name | Frontend | | `frontend/` |

Each member must be able to explain the other two parts at component level during the viva.
