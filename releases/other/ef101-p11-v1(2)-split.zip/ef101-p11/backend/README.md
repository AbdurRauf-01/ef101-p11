# Part 2: Backend

Owns the application logic: routes, validation, the "needs attention" rule, dashboard queries, CSV export and tests.

- `app.py` - Flask routes (`/dashboard`, `/assets`, `/assets/new`, `/assets/<id>`, edit, retire, reactivate, maintenance, exports). Rule constants are at the top.
- `db.py` - opens SQLite connections (`get_db`) and creates tables from `../database/schema.sql` (`init_db`).
- `test_app.py` - automated tests on a temporary database; prints a results table for the report.

Run from this folder:
```
python app.py        # http://127.0.0.1:5000
python test_app.py   # expects 34/34 passed
```

The backend loads HTML from `../frontend/templates` and CSS/JS from `../frontend/static`.
