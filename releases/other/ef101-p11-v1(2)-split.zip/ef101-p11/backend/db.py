"""Database helpers (SQLite via the built-in sqlite3 module)."""
import sqlite3
from pathlib import Path

BASE = Path(__file__).resolve().parent                 # backend/
DATABASE_DIR = BASE.parent / "database"
DB_PATH = DATABASE_DIR / "inventory.db"
SCHEMA_PATH = DATABASE_DIR / "schema.sql"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")   # enforce maintenance.asset_id -> assets
    return conn


def init_db():
    """(Re)create the tables from schema.sql. Used by seed.py; wipes existing data."""
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
    conn.commit()
    conn.close()
