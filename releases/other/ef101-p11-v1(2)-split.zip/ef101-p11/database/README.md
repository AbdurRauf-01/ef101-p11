# Part 1: Database

Owns the data structure and the stored data.

- `schema.sql` - defines the `assets` table (one row per computer) and `maintenance` table (many events per asset). Running it wipes and recreates both tables.
- `seed.py` - generates 40 reproducible demo assets and about 40 maintenance events (fixed random seed). It uses the connection helper in `backend/db.py`.
- `inventory.db` - the SQLite database file the backend reads and writes.

Run from this folder:
```
python seed.py
```

Key points to explain in the viva:
- Why SQLite (a single file, no server, built into Python).
- `asset_id` is the primary key (permanent identity). `ip_address` is not identity because it can change.
- `warranty_status` is not stored; it is computed from `warranty_expiry`.
- Deleting `inventory.db` breaks the app until `python seed.py` is run again.
