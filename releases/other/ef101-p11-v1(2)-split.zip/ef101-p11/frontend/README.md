# Part 3: Frontend

Owns what the user sees: page layout, forms, tables, dashboard charts and styling.

- `templates/` - Jinja HTML pages: `base.html` (shared menu and layout), `dashboard.html`, `assets.html`, `asset_form.html`, `asset_detail.html`, `message.html`.
- `static/` - `style.css` (custom styles), `bootstrap.min.css` and `bootstrap.bundle.min.js` (Bootstrap, local copy), `chart.umd.min.js` (Chart.js, local copy).

The frontend has no database code. It only displays values that the backend passes into each template. To change a label or layout, edit the templates or CSS here. Variable names such as `a.asset_id` come from the backend, so keep them unchanged unless the backend changes too.

No separate server is needed. The backend serves these files when run.
