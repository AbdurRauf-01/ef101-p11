# EF101-P11 Computer Hardware Inventory and Maintenance System

Flask + SQLite web app that tracks computer assets (specs, location, warranty, status), their maintenance/fault history, a dashboard and CSV export. All data in `database/inventory.db` is **DEMO data**, not real assets.

## Repository layout (three parts)

```
ef101-p11/
├── database/   Part 1 - schema, demo data generator, SQLite database file
├── backend/    Part 2 - Flask routes, validation, queries, DB connection, tests
├── frontend/   Part 3 - HTML templates (Jinja), CSS, local Bootstrap and Chart.js
└── docs/       Shared project schema diagram
```

| Part | Folder | Contains | Main file(s) |
|---|---|---|---|
| Database | `database/` | Table definitions, demo data, DB file | `schema.sql`, `seed.py`, `inventory.db` |
| Backend | `backend/` | Business rules, routes, CSV export, DB access, tests | `app.py`, `db.py`, `test_app.py` |
| Frontend | `frontend/` | Pages the user sees, styling, charts | `templates/*.html`, `static/*` |

Each part has its own README with the details for its owner.

## Run

Run the commands from the folder named in each line.

```
pip install flask
cd database && python seed.py     # optional: recreates inventory.db with demo data
cd backend  && python app.py      # then open http://127.0.0.1:5000
cd backend  && python test_app.py # 34 checks on a temporary database
```

No Internet is needed: Bootstrap and Chart.js are served from `frontend/static/`.

## Rules to document in the report

- **Needs attention** (active assets only): status is Faulty or Under Repair, OR 3+ maintenance events, OR warranty expires within 30 days. Constants `ATTENTION_FAULT_COUNT` and `WARRANTY_SOON_DAYS` are at the top of `backend/app.py`.
- **Warranty status** is computed from `warranty_expiry` (Active / Expiring soon / Expired), never stored.
- **Retire** sets `active = 0`; the row and its history are kept. Reactivate reverses it.
- **Validation**: required fields, RAM/storage positive integers, valid IP, valid dates, purchase date not in the future, warranty not before purchase, duplicate asset ID rejected, event cost >= 0.
- All SQL uses `?` placeholders (no string-built values), so search input cannot inject SQL.

## Tool and AI disclosure (edit before submitting)
Built with Python, Flask, SQLite, Bootstrap, Chart.js. Code was drafted with help from Claude (Anthropic) and reviewed, tested and understood by all team members. List exactly which parts and what each member changed.

## Limitations
No login or user roles; data entry is manual; SQLite suits one site and few concurrent users; demo data is synthetic. The frontend is server-rendered by Flask (Jinja templates), so it is separated by folder but is not a separately deployed app.
